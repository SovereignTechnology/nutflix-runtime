import type { Endpoints, InitOptions, OpenOptions, RemoteCandidates, ResolveOptions, ResolvedManifest, Session, Signaling } from './api';
export type * from './api';
/** Most trackers one session takes. */
export declare const MAX_TRACKERS: number;
/** Most relays one session's Nostr signaling takes (NFX-10 §6). */
export declare const MAX_RELAYS: number;
/** The Nostr signaling kind, and the protocol identifier its events carry (NFX-10 §6). */
export declare const NOSTR_SIGNAL_KIND: number;
export declare const NOSTR_SIGNAL_PROTOCOL: string;
/** Most STUN servers one session takes. */
export declare const MAX_ICE_SERVERS: number;
/** Most rendition ids `open()`'s `renditions`, and an `OriginSource`'s, take. */
export declare const MAX_RENDITIONS: number;
/**
 * A tracker URL a page may configure, reduced to scheme, host, port and path: `wss:`, or
 * `ws:` on a loopback host (tests). No credentials, query or fragment. `null` otherwise.
 * (Trackers from beacons must also be `wss:`; `watchEndpoints` sees to that.)
 */
export declare function trackerUrl(raw: string): string | null;
/**
 * A relay URL a session may signal through (NFX-10 §6), reduced to scheme, host, port and
 * path: `wss:`, or `ws:` on a loopback host (tests). No credentials, query or fragment.
 * `null` otherwise.
 */
export declare function relayUrl(raw: string): string | null;
/**
 * `signaling` as `open()` will take it, normalised (URLs reduced, duplicates dropped), or
 * `null` for none; throws a `TypeError` for anything `open()` refuses, so a page can check
 * its settings first.
 */
export declare function checkSignaling(signaling: Signaling | undefined): Signaling | null;
/** A beacon-named origin as a plain `https://host[:port][/prefix]` base, or null. */
export declare function originBase(url: string): string | null;
/** Most candidates `remoteCandidates: 'global'` keeps from one SDP. */
export declare const MAX_REMOTE_CANDIDATES: number;
/**
 * A peer's SDP cut to the candidates `mode` lets an ICE agent try (`RemoteCandidates`), as
 * `open()` applies it with Nostr signaling's `remoteCandidates`: `all` returns it as it is;
 * `global` keeps at most `MAX_REMOTE_CANDIDATES` UDP candidates at global unicast addresses,
 * in the strict form browsers write, and every other line byte for byte. Pure, and never
 * throws for an SDP left with no candidate; throws a `TypeError` for another mode.
 */
export declare function filterRemoteSdp(sdp: string, mode: RemoteCandidates): string;
/** Load the WASM verifier (once). Every other call waits for it; call this first. */
export declare function init(options?: InitOptions): Promise<void>;
/** The current revision of the manifest at `a` across `relays` (`ws://` or `wss://` URLs). */
export declare function resolveManifest(a: string, relays: string[], options?: ResolveOptions): Promise<ResolvedManifest>;
/**
 * Report the origins, trackers and STUN servers seeders' live beacons for `a` name, and
 * which renditions they hold, each time that changes (the newest unexpired beacon per
 * seeder counts, at most 64 seeders; `https://` origins only, at most 8, with the
 * renditions beacons claim each serves, a hint for `open()`; `wss://` trackers only, at
 * most 4; global unicast STUN addresses only, at most 4; `availability`). Returns `stop`,
 * which closes the subscriptions.
 */
export declare function watchEndpoints(a: string, namespace: string, relays: string[], onChange: (endpoints: Endpoints) => void): () => void;
/**
 * Play a video in `el`. Resolves once a hash list has verified, the origin has answered
 * which allowed renditions it holds, and hls.js has started; levels follow (`levels`
 * event). Rejects if the manifest fails NFX-02, if no origin serves a hash list that
 * verifies and answers for an allowed rendition's init (`OpenCommon` has the rule), if
 * `renditions` names one the hash list lacks, if MediaSource is missing (native HLS would
 * play unverified bytes), or if `signal` aborts first. A rejected `open()` leaves nothing
 * running.
 */
export declare function open(el: HTMLVideoElement, options: OpenOptions): Promise<Session>;
